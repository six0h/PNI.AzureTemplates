#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration CreateFileShareWitness
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

	[Parameter(Mandatory)]
	$OUPath,

        [Parameter(Mandatory)]
        [String]$SharePath,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xDSCDomainjoin, xSmbShare, cDisk, xDisk, xActiveDirectory
    
    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xDSCDomainjoin JoinDomain
        {
            Domain = $DomainName
            Credential = $Credential  # Credential to join to domain
            JoinOU = $OUPath
        }

        File FSWFolder
        {
            DestinationPath = "F:\$($SharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
            DependsOn = "[xDSCDomainjoin]JoinDomain"
        }

        xSmbShare FSWShare
        {
            Name = $SharePath.ToUpperInvariant()
            Path = "F:\$($SharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators"
            Ensure = "Present"
            DependsOn = "[File]FSWFolder"
        }
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }
    }     
}
